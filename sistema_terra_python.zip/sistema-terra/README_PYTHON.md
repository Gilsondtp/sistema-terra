# Sistema Terra — Versão em Python + SQLite

Aplicação recriada em **Python (Flask + SQLite)** preservando todas as funções do sistema original em PHP/MySQL e incorporando as novas funcionalidades solicitadas:

## Principais Funcionalidades e Alterações Implementadas

1. **Primeira Tela — `LANC. DIÁRIO` (`/lancamento-diario` ou `/`)**:
   - Exibe a listagem dos serviços monitorados automaticamente pelo Hot Folder e lançados no dia (ou outra data selecionada).
   - **Barra Superior**: Seletor de modo de exibição (*Lançamento Diário (Padrão)*, *Por Cliente*, *Por Produto*, *Por Descrição do Serviço*, *Apenas Não Identificados*), filtros por data/cliente/produto/texto, **Fechamento do Mês / Virada de Mês**, botão **Testar / Simular Hot Folder**, **Atualizar Pasta** e **Imprimir Listagem**. Esta tela acompanha os lançamentos automáticos e não oferece edição/exclusão.
   - O fechamento mensal atualiza saldos de clientes e organiza os lançamentos de serviço, mas **preserva o histórico financeiro da tela Caixa** (receitas, despesas, recebimentos e pagamentos).
   - **Destaque em Vermelho para Não Identificados**: Serviços cujo cliente não pôde ser identificado pelo nome do arquivo aparecem destacados em **vermelho**, com opção para **Atribuir Cliente** diretamente na linha.
   - **Soma nas Colunas**: Rodapé da tabela com a soma total da **Quantidade de Produto (Chapas)** e a soma de **Valores (R$)** da listagem exibida.
   - **Barra Inferior**: Exibe a quantidade total de serviços, a quantidade de **Não Identificados** e o total de chapas/valores.

2. **Monitoramento Automático de Hot Folder TIFF (`\\RIPCTP\Manuela\OutPut`)**:
   - Monitora as subpastas associadas a cada chapa/produto (ex: `510x400` &rarr; `GTO`, `660x530` &rarr; `Adast`, `650x550` &rarr; `MO`, `521` &rarr; `521`, `745x605` &rarr; `Speed`, `724` &rarr; `724`, `Solna` &rarr; `Solna`).
   - Reconhece arquivos separados pelo RIP (*Raster Precision Screen*) nas cores **`C`, `M`, `Y`, `K`, `GRAY`, `PANTONE`** e múltiplas páginas numeradas.
   - **Tolerância a falta de espaços, acentos, caixa alta/baixa e erros de grafia**: Identifica o cliente por similaridade (Damerau-Levenshtein), reconhecendo variações como `gilso` ou `glison` para `Gilson`, mesmo quando o nome do arquivo está colado sem espaços (ex: `gilsoncartazc.tif`). A descrição apenas recupera espaços e remove marcadores do RIP; não faz correção automática da grafia. Sufixos `C/M/Y/K` ambíguos só são removidos quando há separador, extensão RIP, transição de caixa ou arquivos irmãos confirmando a série.
   - **Normalização pré-RIP separada**: monitora os arquivos `.ps` na origem `\\Ripctp\rip (d:) (z)` (incluindo as subpastas de data) e, após o arquivo ficar estável, troca espaços por `_`. Não altera os TIFFs, o conteúdo nem os nomes das pastas; pode ser desligada separadamente em Configurações.

3. **Segunda Alteração — `PRODUTOS / ESTOQUE` (`/produtos`)**:
   - O controle de estoque permanece unificado e aperfeiçoado na própria tela de Produtos (Chapas), exibindo Estoque Inicial, Consumido, Estoque Atual, Valor de Compra, Valor em Estoque, Preço de Venda, Custo das Chapas Consumidas, Status (`OK`, `BAIXO`, `CRÍTICO`), vínculo de subpasta Hot Folder, ajuste rápido de entrada/saída e impressão.

4. **Terceira Alteração — `CAIXA` (`/caixa`)**:
   - Incorporada ao mesmo banco de dados SQLite (`sistema_terra.db`), exibindo lado a lado os **Saldos Devedores dos Clientes e Pagamentos Lançados** e o fluxo de movimentações do Caixa (Receitas, Despesas, Recebidos, Pagos, A Receber, Transferidos).

5. **Relatório e manutenção de lançamentos**:
   - **Relatório / Fatura Individual (`/relatorios`)**: Emissão de fatura formatada para impressão, relatório de produtos utilizados no período e consulta por intervalo. Na fatura mensal aberta, o botão **Novo lançamento** abre o formulário em pop-up; os botões de edição e exclusão ficam junto a cada item e somem na impressão. O fechamento mensal arquiva os lançamentos sem apagá-los nem alterar Caixa/estoque. Faturas fechadas continuam bloqueadas; após reabri-las pelo histórico, é possível corrigir lançamentos com auditoria e, na primeira fatura registrada do cliente, ajustar o saldo de abertura e recalcular os períodos posteriores.
   - **Formulário de lançamento**: integrado ao relatório em um pop-up, com múltiplos serviços, entrega, pagamento/desconto, fatura anterior e observação. A antiga URL `/lancamentos` redireciona para o relatório.
   - **Clientes (`/clientes`)**: Cadastro, busca, edição e exclusão protegida, com campo opcional de CNPJ formatado.
   - **Demonstrativo (`/demonstrativo`)**: Resumo geral de todos os clientes por período ou produto, produtos utilizados, alerta de estoque crítico, impressão e **Exportação para Excel (`.xlsx`)**.
   - **Backup Fácil (`/configuracoes`)**: Exportação e importação em 1 clique do banco SQLite (`.db`), `.json` ou `.sql`.

## Atualizar sem substituir os dados

O ZIP de atualização contém o código, templates e arquivos estáticos, mas **não inclui** `sistema_terra.db`, backups, dump SQL ou testes que dependem do banco de dados de desenvolvimento. Extraia os arquivos na pasta atual do sistema e mantenha o seu `sistema_terra.db` atualizado. Se extrair em uma pasta nova, copie para ela uma cópia do banco atualizado antes da primeira execução. Não use o banco de exemplo do repositório como substituto dos seus dados.

## Como Executar no Windows

O projeto não inclui o interpretador Python. Na máquina virtual, instale Python 3 para Windows (64 bits) antes de iniciar; inclua o Python Launcher (`py`/`pyw`) na instalação. O `pythonw.exe` faz parte da instalação padrão do Python para Windows.

Na primeira execução, dê dois cliques em **`iniciar_sistema.bat`**. O script localiza o Python pelo Launcher `py` ou por `python`, instala as dependências se necessário e inicia o sistema. Se a instalação não tiver o `pythonw.exe` ao lado do `python.exe`, ele tenta o Launcher `pyw`; se nenhum estiver disponível, mostra instruções em vez de falhar com “não encontrou pythonw”. Antes de abrir o navegador, aguarda até 120 segundos pela resposta do servidor; se não iniciar, informa o caminho do `sistema_terra.log` para diagnóstico, em vez de abrir uma página com conexão recusada.

Depois da configuração inicial, **`iniciar_sem_janela.vbs`** também aguarda a confirmação do servidor antes de abrir o navegador e mostra uma mensagem com o caminho do log se a inicialização falhar. Também é possível executar manualmente no terminal:

```bash
python -m pip install -r requirements.txt
python app.py
```

Depois acesse no navegador: `http://127.0.0.1:5000`. Esse endereço é local à máquina em que o servidor está rodando; para acessar de outro computador, use o IP da máquina principal na rede (por exemplo, `http://192.168.x.x:5000`) e permita o Python no Firewall do Windows.
